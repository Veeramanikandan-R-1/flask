from common_code.common_macros import mysql_cursor
values=('mani',)
mysql_cursor.execute('select email_otp from users_tb where email_id=%s',values)
otp=mysql_cursor.fetchall()
print(otp,'otp')
if otp:
    print('y')
else:
    print('n')