import time

from flask_wtf import Form
from flask import request,Flask,flash,render_template,redirect,url_for
from wtforms import IntegerField,StringField,TextAreaField,SubmitField,RadioField,SelectField,PasswordField
from wtforms import validators,ValidationError
from flask import current_app
from flask_mail import *
from random import randint
import json,os
import re
import logging,threading,base64

from common_code.common_macros import *

logging.basicConfig(level=10,format='%(asctime)s - USER-MGMT - %(levelname)s - %(message)s',filename=log_file_name,filemode='a')

class sign_up_form(Form):
    name=StringField("Name",[validators.input_required()])
    gender=RadioField('Gender',choices=[('M',"Male"),('F','Female'),('O',"Others")])
    address=TextAreaField("Address")
    phone_number=IntegerField("Mobile number")
    email=StringField("Email",[validators.input_required("enter email address"),validators.Email()])
    password = PasswordField("Password", [validators.input_required("Enter password")])
    confirm_password = PasswordField("Confirm Password", [validators.input_required("Enter password")])
    age=IntegerField('Age')
    nationality=SelectField('Choose your nationality',choices=[('Indian','Indian'),('Others','Others')])
    submit=SubmitField('submit')

def user_mgmt_fun():
    form=sign_up_form()
    return render_template('user_management_templates/signup.html',form=form)

def expire_otp_timer(mail_id):
    time.sleep(30)
    mysql_cursor.execute('update users_tb set email_otp=%s where email_id=%s',(otp_expired_val,mail_id))
    mysql_db.commit()

def email_otp_verification_fun():
    user_details = {}
    if request.method == 'POST':
        email_otp_verification_fun.email_entered = request.form['email']
        user_details["email"] = email_otp_verification_fun.email_entered
        user_details['password'] = request.form['password']
        user_details['confirm_password'] = request.form['confirm_password']
        user_details['mobile_number'] = request.form['phone_number']
        user_details['age'] = int(request.form['age'])
        user_details['gender']=request.form['gender']
        mobile_number_validation = re.findall("^(0|91)?[7-9][0-9]{9}$", user_details['mobile_number'])
        password_validation1=re.findall('^(?=(.*[a-z]){3,})(?=(.*[A-Z]){2,})(?=(.*[0-9]){2,})(?=(.*[!@#$%^&*()\-__+.]){1,}).{8,}$',user_details['password'])
        password_validation2=(user_details['password']==user_details['confirm_password'])
        # validating email existence in db
        mysql_cursor.execute('select id from users_tb where email_id=%s', (user_details["email"],) )
        email_id_exist = mysql_cursor.fetchall()
        if not password_validation1 or not password_validation2 or email_id_exist or not mobile_number_validation or (user_details['age']) not in range(18, 100):
            flash('** Correct the errors')
            if not password_validation1:
                flash('** your password doesn\'t satisfies conditions')
            if not password_validation2:
                flash('** password and confirm password should be same')
            if email_id_exist:
                flash('** email_id already exists try with another email')
            if not mobile_number_validation:
                flash('** enter valid mobile number')
            if (user_details['age']) < 18:
                flash('** user age must be above 18')
            elif (user_details['age']) not in range(18, 100):
                flash('** enter valid age')
            form = sign_up_form()
            return render_template('user_management_templates/signup.html', form=form)
        logging.info("user details is {}".format(user_details))
        email_otp_verification_fun.otp= randint(000000, 999999)
        mail = Mail(current_app)  # use current app or else mail key error will occur

        with open("user_management/user_details.json",'w') as file:
            json.dump(user_details,file)
        password = user_details['password'].encode("utf-8")

        encoded_password = base64.b64encode(password)
        decoded = base64.b64decode(encoded_password)


        mysql_cursor.execute("insert into users_tb(user_name,address,mobile_no,email_id,user_password,age,nationality,email_otp)  values(%s,%s,%s,%s,%s,%s,%s,%s);",(request.form['name'],request.form['address'],request.form['phone_number'],request.form['email'],encoded_password,request.form['age'],request.form['nationality'],email_otp_verification_fun.otp))
        mysql_db.commit()

        msg = Message('OTP for verification', sender=sender_mail_id, recipients=[email_otp_verification_fun.email_entered])
        msg.body = "OTP for email verification is {}".format(email_otp_verification_fun.otp)
        mail.send(msg)

        # timer to update the expired otp to db
        expire_otp_thread=threading.Thread(target=expire_otp_timer,args=[user_details["email"]])
        expire_otp_thread.start()
        logging.info('otp sent is {}'.format(email_otp_verification_fun.otp))
        return render_template('user_management_templates/verify_email_otp.html',email=email_otp_verification_fun.email_entered)

def email_otp_verification_resend_fun():
    email_otp_verification_resend_fun.otp= randint(000000, 999999)
    mail = Mail(current_app)  # use current app or else mail key error will occur
    user_details = {}
    with open("user_management/user_details.json",'r') as file:
        user_details.update(json.loads(file.read()))
    # print(user_details)
    email_entered=user_details["email"]
    msg = Message('OTP for verification', sender=sender_mail_id, recipients=[email_entered])
    msg.body = "OTP for email verification is {}".format(email_otp_verification_resend_fun.otp)
    mail.send(msg)
    logging.info('otp resended is {}'.format(email_otp_verification_resend_fun.otp))
    return render_template('user_management_templates/verify_email_otp.html',email=email_entered)

def validate_fun():
    user_otp=request.form['otp_entered']
    logging.info('otp entered is {}'.format(user_otp))
    email_otp_verification_fun.email_entered='rsvhmani98@gmail.com'
    mysql_cursor.execute('select email_otp from users_tb where email_id=%s', (email_otp_verification_fun.email_entered,))
    otp = mysql_cursor.fetchall()

    if otp[0][0]==int(user_otp):
        logging.info('otp verified successfully')
        return "<h3>Email verified successfully</h3>"

    if otp[0][0]==0:
        flash('** otp expired click resend button')
        return render_template('user_management_templates/verify_email_otp.html',email=email_otp_verification_fun.email_entered,otp_type='expired')

    elif otp[0][0]!=int(user_otp):
        flash('** enter correct otp')
        return render_template('user_management_templates/verify_email_otp.html',email=email_otp_verification_fun.email_entered)

    else:
        logging.info('error occured while verifying otp')
        return "<h3>failure</h3>"



