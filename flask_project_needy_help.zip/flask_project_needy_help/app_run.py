import threading
from DB_CODES.db_common import starting_mysql_server
import os,time
os.chdir("D://mani//2//flask//flask_project_needy_help")
print(os.getcwd())
from user_management.user_mgmt import *

app =Flask(__name__)
app.secret_key="needy_help"

sender_mail_id="manirsvh98@gmail.com"
sender_mail_password="Mani123#"
# flask mail configuration
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT']=465
app.config['MAIL_USERNAME']=sender_mail_id
app.config['MAIL_PASSWORD']=sender_mail_password
app.config['MAIL_USE_TLS']=False
app.config['MAIL_USE_SSL']=True


@app.route('/')
def home_page():
    return render_template('home.html')



app.add_url_rule('/user_mgmt','user_mgmt_fun',user_mgmt_fun,methods=['GET','POST'])

# app.add_url_rule('/login','login_fun',login_fun,methods=['GET','POST'])

app.add_url_rule('/email_otp_verification','email_otp_verification_fun',email_otp_verification_fun,methods=['GET','POST'])

app.add_url_rule('/email_otp_resend_verification','email_otp_verification_resend_fun',email_otp_verification_resend_fun,methods=['GET','POST'])

app.add_url_rule('/validate', 'validate_fun', validate_fun, methods=['POST'])

app.run(debug=True)