import logging

from common_code.common_macros import db_execution_file_path
import subprocess,os,re,codecs

print(os.getcwd())
os.chdir(db_execution_file_path)
print(os.getcwd())

def command_executor_fun(command):
    proc = subprocess.Popen(command,shell=True, stdin = subprocess.PIPE, stdout = subprocess.PIPE)
    out,err=proc.communicate()
    if out:
        # print(out)
        return out
    elif err:
        # print(err)
        return err

# # command_executor_fun('mysqld.exe -u root --console')
# output=command_executor_fun("netstat -aon | find \"3306\"")
# print(output)
#
# # data = str(codecs.decode(output, 'unicode_escape'))
# data=str(output)
# print(type(output))
# match=list(set(re.findall('[0-9]{3,4}',data)))
# match= [x for x in match if x!='3306']
# print(int(match[0]))
# print(match)
# output=command_executor_fun('taskkill /pid {} /f'.format(int(match[0])))
# print(output)

def stopping_mysql_server():
    output = command_executor_fun("netstat -aon | find \"3306\"")
    # print(output)

    data = (str(codecs.decode(output, 'unicode_escape'))).splitlines()[0]
    logging.info('netstat mysql command output is {}'.format(data))
    match = (re.findall('[0-9]{3,7}', data))
    match = [x for x in match if x != '3306']
    output = command_executor_fun('taskkill /pid {} /f'.format((match[0])))
    print(output)
    if "SUCCESS" in str(codecs.decode(output,'unicode_escape')):
        print('stopped mysql server succesfully')
    else:
        print('error occurred while stopping the mysql server')
# stopping_mysql_server()
from db_common import stopping_mysql_server
stopping_mysql_server()