import time

# from common_code.common_macros import db_execution_file_path,log_file_name
import subprocess,os,logging,codecs,re,threading
db_execution_file_path='D:\\MySQL Server 8.0\\bin'
current_working_directory='D:\\mani\\2\\flask\\flask_project_needy_help'
# logging.basicConfig(level=10,format='%(asctime)s - DB - %(levelname)s - %(message)s',filename=log_file_name,filemode='a')
def command_executor_fun(command,dict):
    logging.info('executing command: {}'.format(command))
    proc = subprocess.Popen(command,shell=True, stdin = subprocess.PIPE, stdout = subprocess.PIPE)
    out,err=proc.communicate()
    if out:
        logging.info('successfully executed command: {}'.format(out))
        dict.append(out)
        return "success"
    elif err:
        logging.info('error occured while executing command executed command: {}'.format(err))
        dict.append(err)
        return "failure"

def checking_whether_mysql_server_fun():
    output_list=[]
    result=command_executor_fun("netstat -aon | find \"3306\"",output_list)
    output=output_list[0]
    if result=='success':
        data = (str(codecs.decode(output, 'unicode_escape'))).splitlines()[0]
        logging.info('netstat mysql command output is {}'.format(data))
        match = (re.findall('[\d]{3,7}', data))
        checking_whether_mysql_server_fun.match = [x for x in match if x != '3306']
        if match[0]:
            logging.info('mysql server started and running with process id {}'.format(checking_whether_mysql_server_fun.match[0]))
            print('mysql server started and running with process id {}'.format(
                checking_whether_mysql_server_fun.match[0]))
        else:
            logging.info('mysql server not started')

def starting_mysql_server():
    # changing the current directory to dir where mysql server resides
    os.chdir(db_execution_file_path)
    output_result=[]
    output=command_executor_fun('mysqld.exe -u root --console',output_result)
    os.chdir(current_working_directory)
    # print(output)
    # print(output_result)


def stopping_mysql_server():
    # changing the current directory to dir where mysql server resides
    # os.chdir(db_execution_file_path)
    output_list=[]
    logging.info('stopping my sql server')
    os.chdir(db_execution_file_path)
    output = command_executor_fun('taskkill /pid {} /f'.format(checking_whether_mysql_server_fun.match[0]),output_list)
    os.chdir(current_working_directory)
    if "SUCCESS" in str(codecs.decode(output_list[0], 'unicode_escape')):
        logging.info('stopped mysql server succesfully')
    else:
        logging.info('error occurred while stopping the mysql server')
# starting_mysql_server()

# time.sleep(5)
# checking_whether_mysql_server_fun()
# time.sleep(5)
# stopping_mysql_server()