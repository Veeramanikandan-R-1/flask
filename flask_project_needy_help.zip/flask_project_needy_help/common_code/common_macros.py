from flask import Flask
import sqlite3
import mysql.connector
import threading
from DB_CODES.db_common import starting_mysql_server
import time

sender_mail_id="manirsvh98@gmail.com"
sender_mail_password="Mani123#"

app =Flask(__name__)
app.secret_key="needy_help"

# Flask mail configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = sender_mail_id
app.config['MAIL_PASSWORD'] = sender_mail_password
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

# db connection
conn=sqlite3.connect("D:\\mani\\2\\flask\\flask_project_needy_help\\needy_help.db",check_same_thread=False)
current_working_directory='D:\\mani\\2\\flask\\flask_project_needy_help'
db_execution_file_path='D:\\MySQL Server 8.0\\bin'
sqlserver_startup_command= 'sqld.exe -u user -p startup --console'
#
starting_server_thread=threading.Thread(target=starting_mysql_server)
starting_server_thread.start()
time.sleep(5)
# # MYSQL DB CONNECTION
mysql_db = mysql.connector.connect(
  host="localhost",
  user="user",
  password="startup",
    database='needyhelp'
)
mysql_cursor = mysql_db.cursor()

# log file details
log_file_name='logs/nhelp.log'

otp_expired_val=0